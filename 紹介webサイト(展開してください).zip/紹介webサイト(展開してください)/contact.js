

function open() {
    var button = document.getElementById('open');
    var form = document.getElementById('form');
    form.style.display = 'block';
    button.style.display = 'none';

}
function close() {
    var button = document.getElementById('open');
    var form = document.getElementById('form');
    form.style.display = 'block';
    button.style.display = 'none';

}
var button = document.getElementById('open');
button.addEventListener('mouseover', open);
var send = document.getElementById('send');
send.addEventListener('click', close);

